-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2012 at 08:13 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `auditdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `database_tb`
--

CREATE TABLE IF NOT EXISTS `database_tb` (
  `dbname` varchar(255) DEFAULT NULL,
  `isss` varchar(255) DEFAULT NULL,
  `dbcontent` varchar(255) DEFAULT NULL,
  `dbstatus` varchar(255) DEFAULT NULL,
  `dbstorage` varchar(255) DEFAULT NULL,
  `dbid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dbid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `database_tb`
--

INSERT INTO `database_tb` (`dbname`, `isss`, `dbcontent`, `dbstatus`, `dbstorage`, `dbid`) VALUES
('try', 'try', 'try', 'Operational', 'try ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `infosystems`
--

CREATE TABLE IF NOT EXISTS `infosystems` (
  `pid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `InfoSystemName` varchar(255) DEFAULT NULL,
  `InfoSystemDescription` varchar(255) DEFAULT NULL,
  `InfoSystemStatus` varchar(255) DEFAULT NULL,
  `InfoSystemDeployment` varchar(255) DEFAULT NULL,
  `InfoSystemDevelopment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `infosystems`
--

INSERT INTO `infosystems` (`pid`, `InfoSystemName`, `InfoSystemDescription`, `InfoSystemStatus`, `InfoSystemDeployment`, `InfoSystemDevelopment`) VALUES
(2, 'try', 'try', 'Operational', 'try', 'In-house'),
(3, 'try2', 'try2', 'Operational', 'try2', 'In-house'),
(4, 'try', 'try', 'Operational', 'try', 'In-house'),
(5, 'try', 'try', 'Operational', 'try', 'In-house');

-- --------------------------------------------------------

--
-- Table structure for table `network`
--

CREATE TABLE IF NOT EXISTS `network` (
  `nid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `hubs` varchar(255) DEFAULT NULL,
  `routers` varchar(255) DEFAULT NULL,
  `switches` varchar(255) DEFAULT NULL,
  `wire` varchar(255) DEFAULT NULL,
  `internet` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `NetworkUnit` int(255) DEFAULT NULL,
  `NetworkDeployment` varchar(255) DEFAULT NULL,
  `bandwith` varchar(255) DEFAULT NULL,
  `MonthlyCost` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `network`
--

INSERT INTO `network` (`nid`, `hubs`, `routers`, `switches`, `wire`, `internet`, `video`, `others`, `NetworkUnit`, `NetworkDeployment`, `bandwith`, `MonthlyCost`) VALUES
(1, 'fdsaf', 'aff', 'afaf', 'af', 'afdsg', 'afa', 'affaf', 0, '0', NULL, 'af');

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `sid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `ServerItem` varchar(255) DEFAULT NULL,
  `ServerDeployment` varchar(255) DEFAULT NULL,
  `SeverUnit` int(255) DEFAULT NULL,
  `YearsUsed` int(255) DEFAULT NULL,
  `ServerRecomendation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `server`
--

INSERT INTO `server` (`sid`, `ServerItem`, `ServerDeployment`, `SeverUnit`, `YearsUsed`, `ServerRecomendation`) VALUES
(1, 'try', NULL, 0, 0, 'Operational'),
(2, 'try', 'try', 1, 0, 'Operational'),
(3, 'try2', 'try', 0, 0, 'Operational'),
(4, 'try', 'try', 1, 1, 'Operational'),
(5, 'try', 'try', 1, 1, 'Optimize');

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

CREATE TABLE IF NOT EXISTS `software` (
  `swid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `SoftwareItem` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `LicenseType` varchar(255) DEFAULT NULL,
  `NumberofLicenses` int(255) DEFAULT NULL,
  PRIMARY KEY (`swid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `software`
--

INSERT INTO `software` (`swid`, `SoftwareItem`, `version`, `LicenseType`, `NumberofLicenses`) VALUES
(1, 'ar', 'sija', 'Opensource', 1);

-- --------------------------------------------------------

--
-- Table structure for table `workstation`
--

CREATE TABLE IF NOT EXISTS `workstation` (
  `wid` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `WorkstationItem` varchar(255) DEFAULT NULL,
  `deployment` varchar(255) DEFAULT NULL,
  `admin` int(255) DEFAULT NULL,
  `research` int(255) DEFAULT NULL,
  `teaching` int(255) NOT NULL,
  `total` int(255) DEFAULT NULL,
  `recommendation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `workstation`
--

INSERT INTO `workstation` (`wid`, `WorkstationItem`, `deployment`, `admin`, `research`, `teaching`, `total`, `recommendation`) VALUES
(1, 'try', 'try', 0, 1, 0, 3, 'Optimize');
